# Vinayak ProEdu — Portal (New Build)

Fresh repo for the Vinayak ProEdu learning portal (ACCA coaching). Safe to experiment —
the live site runs from the old repo until you switch over.

## Structure
    index.html            Landing page (Student / Admin entry)
    manifest.json         PWA manifest (installable app)
    sw.js                 Service worker (offline shell)
    icon-*.png            App icons
    admin/                Admin panel (dashboard, tests, students, lectures, live, leaderboard, doubts)
    student/              Student portal (courses, lectures, mocks engine, doubts, leaderboard)

## Stack
- Firebase Auth + Firestore (same project as before: `vinayak-proedu`)
- PWA — installable on iOS, Android, macOS, Windows (free, no app stores needed)
- Admin mocks support ACCA Applied Skills / Strategic Professional papers
- Word / Spreadsheet constructed responses are NOT auto-marked — admin marks them
  from Tests → Attempts (✍️ Mark Constructed Responses)

## Deploy (free)
1. Push this repo to GitHub
2. Enable **GitHub Pages**: Settings → Pages → Deploy from branch → `main` / root
3. Site goes live at `https://<user>.github.io/<repo>/`

OR host on any static host (Netlify / Vercel / your own server) — it's plain HTML/JS.

## Local test
Just open `index.html` in a browser, or run `npx serve .`

## Notes
- Admin login: vinayakproedu@gmail.com only (all admin pages enforce this)
- Students log in from the Student Portal (signup creates `users` doc with role=student)
- Mock data lives in Firestore collections: `mockPapers`, `mockQuestions`, `mockAttempts`
- Attempts with constructed responses get status `pending_marking` until admin finalises
