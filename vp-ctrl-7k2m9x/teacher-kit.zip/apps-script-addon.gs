/* ============================================================
   ADD-ON: Teacher invitation webhook
   1. Paste this at the BOTTOM of your existing Apps Script
      (Extensions → Apps Script in the Webinar sheet)
   2. Then: Deploy → New deployment → type "Web app" →
      Execute as: Me → Who has access: ANYONE → Deploy
   3. Copy the Web app URL it gives you (ends in /exec)
      and paste it into teachers.html where marked WEBHOOK_URL
   ============================================================ */
const WEBHOOK_SECRET = 'vp-teach-2026';   // shared secret — keep private

function doPost(e) {
  try {
    const p = JSON.parse(e.postData.contents || '{}');
    if (p.key !== WEBHOOK_SECRET) return ContentService.createTextOutput('bad key');
    const html = '<div style="font-family:Arial;max-width:560px;margin:auto;border:1px solid #e5e7eb;border-radius:16px;overflow:hidden">'
      + '<div style="background:linear-gradient(135deg,#0D1B40,#1e3c72);color:#fff;padding:28px;text-align:center"><h2 style="margin:0">Welcome to Vinayak ProEdu!</h2><p style="opacity:.8">Your teacher access is ready</p></div>'
      + '<div style="padding:28px;line-height:1.7;color:#1A1A2E"><p>Hi <b>' + (p.name || 'there') + '</b>,</p>'
      + '<p>You have been added as a faculty member for: <b>' + (p.subjects || '') + '</b></p>'
      + '<div style="background:#f8fafc;border:1px solid #e5e7eb;border-radius:12px;padding:16px;margin:16px 0">'
      + '<p><b>Portal link:</b> <a href="https://www.vinayakproedu.com/vp-ctrl-7k2m9x/">https://www.vinayakproedu.com/vp-ctrl-7k2m9x/</a></p>'
      + '<p><b>Email:</b> ' + p.email + '</p><p><b>Password:</b> ' + p.password + '</p></div>'
      + '<p>Please log in and change your password via <b>Forgot password?</b> on the login screen if you wish. You can manage lectures, live classes, mocks, leaderboard and announcements for your assigned subjects only.</p>'
      + '<p>Team Vinayak ProEdu</p></div></div>';
    MailApp.sendEmail({ to: p.email, subject: 'Your Teacher Access — Vinayak ProEdu 👨‍🏫', htmlBody: html, name: 'Vinayak ProEdu' });
    return ContentService.createTextOutput('ok');
  } catch (err) {
    return ContentService.createTextOutput('error: ' + err.message);
  }
}
